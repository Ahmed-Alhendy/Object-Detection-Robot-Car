/*
 * Color search - vision part
 * Board: ESP32-WROVER-E dev board + OV2640 (WROVER-DEV camera pinout)
 *
 * Serial output (9600 baud, TX = GPIO1 / U0T):
 *   $found,x,area
 *     found : 1 = color visible, 0 = not visible, -1 = stop (bad switches / camera error)
 *     x     : -100 (far left) .. 100 (far right)
 *     area  : size of the largest blob, % of the image
 *   Lines starting with '#' are debug text. The receiver must ignore
 *   every line that does not start with '$'.
 *
 * Switches: connect each one between the pin and GND. Exactly ONE must be ON.
 *   RED = GPIO13, GREEN = GPIO14, BLUE = GPIO15   (SD card must not be used)
 */
#include "esp_camera.h"

// ---------- Settings ----------
#define DEBUG_HSV 1          // 1 = print HSV of the image center (for tuning)
const long BAUD = 9600;
const int MIN_BLOB = 80;     // smaller blobs are treated as noise (pixels)

const int PIN_RED = 13;
const int PIN_GREEN = 14;
const int PIN_BLUE = 15;

// ---------- Color ranges (OpenCV scale: H 0-179, S and V 0-255) ----------
struct ColorRange {
  const char *name;
  int h1Min, h1Max;
  int h2Min, h2Max;          // second hue range (red only), -1 if unused
  int sMin, vMin;
};

const ColorRange COLORS[3] = {
  {"RED",     0,  10, 170, 179, 120, 60},
  {"GREEN",  40,  85,  -1,  -1,  80, 50},
  {"BLUE",   95, 130,  -1,  -1, 120, 50},
};

// ---------- WROVER-DEV camera pins ----------
#define PWDN_GPIO_NUM  -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM   21
#define SIOD_GPIO_NUM  26
#define SIOC_GPIO_NUM  27
#define Y9_GPIO_NUM    35
#define Y8_GPIO_NUM    34
#define Y7_GPIO_NUM    39
#define Y6_GPIO_NUM    36
#define Y5_GPIO_NUM    19
#define Y4_GPIO_NUM    18
#define Y3_GPIO_NUM    5
#define Y2_GPIO_NUM     4
#define VSYNC_GPIO_NUM 25
#define HREF_GPIO_NUM  23
#define PCLK_GPIO_NUM  22

const int IMG_W = 160;       // QQVGA
const int IMG_H = 120;
const int IMG_N = IMG_W * IMG_H;

static uint8_t mask[IMG_N];          // 1 = pixel matches and is not visited yet
static uint16_t pixelStack[IMG_N];   // used to walk through each blob

struct Result {
  int found;
  int x;
  float area;
};

// ---------- Color conversion ----------
// The camera sends RGB565, high byte first.
void readHSV(const uint8_t *buf, int i, int &h, int &s, int &v) {
  uint16_t p = ((uint16_t)buf[2 * i] << 8) | buf[2 * i + 1];
  int r = (p >> 11) & 0x1F;
  int g = (p >> 5) & 0x3F;
  int b = p & 0x1F;
  r = (r << 3) | (r >> 2);
  g = (g << 2) | (g >> 4);
  b = (b << 3) | (b >> 2);

  int maxV = max(r, max(g, b));
  int minV = min(r, min(g, b));
  int d = maxV - minV;

  v = maxV;
  s = (maxV == 0) ? 0 : (255 * d) / maxV;

  if (d == 0) {
    h = 0;
    return;
  }
  int deg;
  if (maxV == r)      deg = (60 * (g - b)) / d;
  else if (maxV == g) deg = 120 + (60 * (b - r)) / d;
  else                deg = 240 + (60 * (r - g)) / d;
  if (deg < 0) deg += 360;
  h = deg / 2;
}

bool matches(const ColorRange &c, int h, int s, int v) {
  if (s < c.sMin || v < c.vMin) return false;
  if (h >= c.h1Min && h <= c.h1Max) return true;
  return c.h2Min >= 0 && h >= c.h2Min && h <= c.h2Max;
}

// ---------- Detection: find the largest connected blob ----------
Result detect(const uint8_t *buf, const ColorRange &c) {
  for (int i = 0; i < IMG_N; i++) {
    int h, s, v;
    readHSV(buf, i, h, s, v);
    mask[i] = matches(c, h, s, v) ? 1 : 0;
  }

  int bestCount = 0;
  long bestSumX = 0;

  for (int start = 0; start < IMG_N; start++) {
    if (!mask[start]) continue;

    int top = 0, count = 0;
    long sumX = 0;
    pixelStack[top++] = start;
    mask[start] = 0;

    while (top > 0) {
      int idx = pixelStack[--top];
      int px = idx % IMG_W;
      int py = idx / IMG_W;
      count++;
      sumX += px;

      // Each pixel is cleared when pushed, so it is pushed only once
      if (px > 0 && mask[idx - 1])             { mask[idx - 1] = 0;     pixelStack[top++] = idx - 1; }
      if (px < IMG_W - 1 && mask[idx + 1])     { mask[idx + 1] = 0;     pixelStack[top++] = idx + 1; }
      if (py > 0 && mask[idx - IMG_W])         { mask[idx - IMG_W] = 0; pixelStack[top++] = idx - IMG_W; }
      if (py < IMG_H - 1 && mask[idx + IMG_W]) { mask[idx + IMG_W] = 0; pixelStack[top++] = idx + IMG_W; }
    }

    if (count > bestCount) {
      bestCount = count;
      bestSumX = sumX;
    }
  }

  Result res = {0, 0, 0.0f};
  if (bestCount >= MIN_BLOB) {
    float cx = (float)bestSumX / bestCount;
    float half = (IMG_W - 1) / 2.0f;
    res.found = 1;
    res.x = (int)lroundf((cx - half) * 100.0f / half);
    res.area = bestCount * 100.0f / IMG_N;
  }
  return res;
}

// ---------- Switches ----------
// Returns 0, 1 or 2. Returns -1 if none or more than one switch is ON.
int readSelectedColor() {
  const int pins[3] = {PIN_RED, PIN_GREEN, PIN_BLUE};
  int selected = -1, onCount = 0;
  for (int i = 0; i < 3; i++) {
    if (digitalRead(pins[i]) == LOW) {
      selected = i;
      onCount++;
    }
  }
  return (onCount == 1) ? selected : -1;
}

// ---------- Tuning helper ----------
int median25(int *a) {
  for (int i = 1; i < 25; i++) {
    int key = a[i], j = i - 1;
    while (j >= 0 && a[j] > key) { a[j + 1] = a[j]; j--; }
    a[j + 1] = key;
  }
  return a[12];
}

void printCenterHSV(const uint8_t *buf) {
  int hs[25], ss[25], vs[25], n = 0;
  for (int dy = -2; dy <= 2; dy++) {
    for (int dx = -2; dx <= 2; dx++) {
      int h, s, v;
      readHSV(buf, (IMG_H / 2 + dy) * IMG_W + (IMG_W / 2 + dx), h, s, v);
      hs[n] = (h >= 90) ? h - 180 : h;   // keeps red values (near 0 and 179) together
      ss[n] = s;
      vs[n] = v;
      n++;
    }
  }
  int h = median25(hs);
  if (h < 0) h += 180;
  Serial.printf("# center H=%d S=%d V=%d\n", h, median25(ss), median25(vs));
}

// ---------- Camera ----------
bool initCamera() {
  camera_config_t config = {};
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;   // old ESP32 cores: pin_sscb_sda
  config.pin_sccb_scl = SIOC_GPIO_NUM;   // old ESP32 cores: pin_sscb_scl
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 10000000;
  config.pixel_format = PIXFORMAT_RGB565;
  config.frame_size = FRAMESIZE_QQVGA;

  if (psramFound()) {
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.fb_count = 2;
    config.grab_mode = CAMERA_GRAB_LATEST;
  } else {
    config.fb_location = CAMERA_FB_IN_DRAM;
    config.fb_count = 1;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
  }
  return esp_camera_init(&config) == ESP_OK;
}

void sendResult(const Result &r) {
  Serial.printf("$%d,%d,%.1f\n", r.found, r.x, r.area);
}

void setup() {
  Serial.begin(BAUD);
  pinMode(PIN_RED, INPUT_PULLUP);
  pinMode(PIN_GREEN, INPUT_PULLUP);
  pinMode(PIN_BLUE, INPUT_PULLUP);

  if (!initCamera()) {
    Serial.println("# camera init failed, restarting");
    sendResult({-1, 0, 0.0f});
    delay(3000);
    ESP.restart();
  }
  Serial.println("# camera ready");
}

void loop() {
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb || fb->len < (size_t)IMG_N * 2) {
    if (fb) esp_camera_fb_return(fb);
    sendResult({-1, 0, 0.0f});
    delay(100);
    return;
  }

  int color = readSelectedColor();
  Result r = {-1, 0, 0.0f};
  if (color >= 0) r = detect(fb->buf, COLORS[color]);

#if DEBUG_HSV
  static unsigned long lastDebug = 0;
  if (millis() - lastDebug > 1000) {
    lastDebug = millis();
    printCenterHSV(fb->buf);
    Serial.printf("# selected: %s\n", color >= 0 ? COLORS[color].name : "NONE (turn on exactly one switch)");
  }
#endif

  esp_camera_fb_return(fb);
  sendResult(r);
  delay(50);
}
